import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'defaultValidation',
  providers: [],
  // styles: ['./default-validation.component.scss'],
  templateUrl: './default-validation.component.html'
})

export class DefaultValidationComponent implements OnInit {
  constructor() {
  }

  public ngOnInit() {
  }
}