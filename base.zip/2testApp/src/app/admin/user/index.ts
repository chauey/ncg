 // index.ts - definitionName
    export { UserComponent } from './user.component';
    export { UserItemComponent } from './user-item.component';
    export { UserListComponent } from './user-list.component';
