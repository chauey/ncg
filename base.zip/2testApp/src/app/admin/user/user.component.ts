import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'user',
  providers: [],
  // styles: ['./user.component.scss'],
  templateUrl: './user.component.html'
})

export class UserComponent implements OnInit {
  constructor() {
  }

  public ngOnInit() {
  }
}