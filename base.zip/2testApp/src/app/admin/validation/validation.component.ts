import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'validation',
  providers: [],
  // styles: ['./validation.component.scss'],
  templateUrl: './validation.component.html'
})

export class ValidationComponent implements OnInit {
  constructor() {
  }

  public ngOnInit() {
  }
}