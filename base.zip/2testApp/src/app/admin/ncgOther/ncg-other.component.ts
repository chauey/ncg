import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ncgOther',
  providers: [],
  // styles: ['./ncg-other.component.scss'],
  templateUrl: './ncg-other.component.html'
})

export class NcgOtherComponent implements OnInit {
  constructor() {
  }

  public ngOnInit() {
  }
}