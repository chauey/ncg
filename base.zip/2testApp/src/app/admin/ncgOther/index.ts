 // index.ts - definitionName
    export { NcgOtherComponent } from './ncg-other.component';
    export { NcgOtherItemComponent } from './ncg-other-item.component';
    export { NcgOtherListComponent } from './ncg-other-list.component';
