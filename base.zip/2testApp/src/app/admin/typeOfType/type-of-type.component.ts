import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'typeOfType',
  providers: [],
  // styles: ['./type-of-type.component.scss'],
  templateUrl: './type-of-type.component.html'
})

export class TypeOfTypeComponent implements OnInit {
  constructor() {
  }

  public ngOnInit() {
  }
}