 // index.ts - definitionName
    export { TypeOfTypeComponent } from './type-of-type.component';
    export { TypeOfTypeItemComponent } from './type-of-type-item.component';
    export { TypeOfTypeListComponent } from './type-of-type-list.component';
