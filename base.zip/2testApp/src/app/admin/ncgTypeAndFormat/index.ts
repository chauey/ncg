 // index.ts - definitionName
    export { NcgTypeAndFormatComponent } from './ncg-type-and-format.component';
    export { NcgTypeAndFormatItemComponent } from './ncg-type-and-format-item.component';
    export { NcgTypeAndFormatListComponent } from './ncg-type-and-format-list.component';
