import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ncgTypeAndFormat',
  providers: [],
  // styles: ['./ncg-type-and-format.component.scss'],
  templateUrl: './ncg-type-and-format.component.html'
})

export class NcgTypeAndFormatComponent implements OnInit {
  constructor() {
  }

  public ngOnInit() {
  }
}