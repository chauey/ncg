import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'tenant',
  providers: [],
  // styles: ['./tenant.component.scss'],
  templateUrl: './tenant.component.html'
})

export class TenantComponent implements OnInit {
  constructor() {
  }

  public ngOnInit() {
  }
}