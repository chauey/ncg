 // index.ts - definitionName
    export { TenantComponent } from './tenant.component';
    export { TenantItemComponent } from './tenant-item.component';
    export { TenantListComponent } from './tenant-list.component';
