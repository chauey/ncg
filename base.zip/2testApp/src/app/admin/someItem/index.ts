 // index.ts - definitionName
    export { someItemComponent } from './some-item.component';
    export { someItemItemComponent } from './some-item-item.component';
    export { someItemListComponent } from './some-item-list.component';
