import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'someItem',
  providers: [],
  // styles: ['./some-item.component.scss'],
  templateUrl: './some-item.component.html'
})

export class someItemComponent implements OnInit {
  constructor() {
  }

  public ngOnInit() {
  }
}