 // index.ts - definitionName
    export { NcgValidationComponent } from './ncg-validation.component';
    export { NcgValidationItemComponent } from './ncg-validation-item.component';
    export { NcgValidationListComponent } from './ncg-validation-list.component';
