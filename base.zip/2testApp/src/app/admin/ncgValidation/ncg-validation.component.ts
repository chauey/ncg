import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ncgValidation',
  providers: [],
  // styles: ['./ncg-validation.component.scss'],
  templateUrl: './ncg-validation.component.html'
})

export class NcgValidationComponent implements OnInit {
  constructor() {
  }

  public ngOnInit() {
  }
}