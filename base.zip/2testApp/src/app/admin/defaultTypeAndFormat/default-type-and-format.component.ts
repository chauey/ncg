import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'defaultTypeAndFormat',
  providers: [],
  // styles: ['./default-type-and-format.component.scss'],
  templateUrl: './default-type-and-format.component.html'
})

export class DefaultTypeAndFormatComponent implements OnInit {
  constructor() {
  }

  public ngOnInit() {
  }
}