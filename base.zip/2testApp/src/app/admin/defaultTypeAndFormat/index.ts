 // index.ts - definitionName
    export { DefaultTypeAndFormatComponent } from './default-type-and-format.component';
    export { DefaultTypeAndFormatItemComponent } from './default-type-and-format-item.component';
    export { DefaultTypeAndFormatListComponent } from './default-type-and-format-list.component';
